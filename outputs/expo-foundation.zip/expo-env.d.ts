/// <reference types="expo/types" />

declare namespace NodeJS {
  interface ProcessEnv {
    EXPO_PUBLIC_APP_NAME?: string;
    EXPO_PUBLIC_API_URL?: string;
    EXPO_PUBLIC_REVENUECAT_APPLE_KEY?: string;
    EXPO_PUBLIC_REVENUECAT_GOOGLE_KEY?: string;
    EXPO_PUBLIC_REVENUECAT_ENTITLEMENT?: string;
    EXPO_PUBLIC_NOTIFICATIONS_ENDPOINT?: string;
    IOS_BUNDLE_ID?: string;
    ANDROID_PACKAGE?: string;
    EAS_PROJECT_ID?: string;
    GOOGLE_SERVICES_FILE?: string;
  }
}
